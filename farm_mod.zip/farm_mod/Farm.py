from mcpi.minecraft import Minecraft
import mcpi.block as block
import time
from mcpi.vec3 import Vec3

mc = Minecraft.create()
pos = mc.player.getTilePos()

#Вычисление позиции перед игроком
def get_build_origin(distance, width, length):
    pos = mc.player.getTilePos()
    rot = mc.player.getRotation() % 360
    x = pos.x
    y = pos.y
    z = pos.z

    #игрок смотрит на юг?
    if 315 <= rot or rot < 45:
        x = pos.x - (width // 2)
        z = pos.z + distance
    # игрок смотрит на запад?
    elif 45 <= rot < 135:
        x = pos.x - distance - width
        z = pos.z - (length // 2)
    #игрок смотрит на север?
    elif 135 <= rot < 225:
        x = pos.x - (width // 2)
        z = pos.z - distance - length
    # игрок смотрит на восток?
    elif 225 <= rot < 315:
       x = pos.x + distance
       z = pos.z - (length // 2)

    return Vec3(x, pos.y, z)

def greenhouse_build(pos, door_side = "x_min", crop_id = 103):
    x = pos.x
    y = pos.y
    z = pos.z

    #основание теплицы
    mc.setBlocks(x, y, z, x+10, y, z+10, 17)
    mc.setBlocks(x+1, y+1, z+1, x+9, y+1, z+9, 17)

    #дорожки воды
    mc.setBlocks(x+2, y+1, z+2, x+8, y+1, z+8, 8)

    #стеклянные стены
    mc.setBlocks(x+1, y+2, z+1, x+9, y+4, z+9, 95)

    # делаем пустоту внутри и вход
    mc.setBlocks(x+2, y+2, z+2, x+8, y+4, z+8, 0)


    #крыша и свет
    mc.setBlocks(x+1, y+5, z+1, x+9, y+5, z+9, 113)
    mc.setBlocks(x+2, y+5, z+2, x+8, y+5, z+8, 112)
    mc.setBlocks(x+3, y+5, z+3, x+7, y+5, z+7, 89)

    #четыре столба по углам стеклянных стен
    mc.setBlocks(x+1, y+2, z+1, x+1, y+4, z+1, 113)
    mc.setBlocks(x+9, y+2, z+9, x+9, y+4, z+9, 113)
    mc.setBlocks(x+1, y+2, z+9, x+1, y+4, z+9, 113)
    mc.setBlocks(x+9, y+2, z+1, x+9, y+4, z+1, 113)

    if door_side == "x_min":
        #вход будет слева
        mc.setBlocks(x + 1, y + 2, z + 4, x + 1, y + 3, z + 6, 0)
        # две грядки с землей
        mc.setBlocks(x + 2, y + 1, z + 3, x + 8, y + 1, z + 4, 3)
        mc.setBlocks(x + 2, y + 1, z + 6, x + 8, y + 1, z + 7, 3)
        # высаживаем урожай
        mc.setBlocks(x + 2, y + 2, z + 3, x + 8, y + 2, z + 4, crop_id)
        mc.setBlocks(x + 2, y + 2, z + 6, x + 8, y + 2, z + 7, crop_id)

    elif door_side == "x_max":
        # вход будет справа
        mc.setBlocks(x + 9, y + 2, z + 4, x + 9, y + 3, z + 6, 0)
        # две грядки с землей
        mc.setBlocks(x + 2, y + 1, z + 3, x + 8, y + 1, z + 4, 3)
        mc.setBlocks(x + 2, y + 1, z + 6, x + 8, y + 1, z + 7, 3)
        # высаживаем урожай
        mc.setBlocks(x + 2, y + 2, z + 3, x + 8, y + 2, z + 4, crop_id)
        mc.setBlocks(x + 2, y + 2, z + 6, x + 8, y + 2, z + 7, crop_id)

    elif door_side == "z_min":
        # вход будет спереди
        mc.setBlocks(x + 4, y + 2, z + 1, x + 6, y + 3, z + 1, 0)
        # две грядки с землей
        mc.setBlocks(x + 3, y + 1, z + 2, x + 4, y + 1, z + 8, 3)
        mc.setBlocks(x + 6, y + 1, z + 2, x + 7, y + 1, z + 8, 3)
        # высаживаем урожай
        mc.setBlocks(x + 3, y + 2, z + 2, x + 4, y + 2, z + 8, crop_id)
        mc.setBlocks(x + 6, y + 2, z + 2, x + 7, y + 2, z + 8, crop_id)

    elif door_side == "z_max":
        # вход будет сзади
        mc.setBlocks(x + 4, y + 2, z + 9, x + 6, y + 3, z + 9, 0)
        # две грядки с землей
        mc.setBlocks(x + 3, y + 1, z + 2, x + 4, y + 1, z + 8, 3)
        mc.setBlocks(x + 6, y + 1, z + 2, x + 7, y + 1, z + 8, 3)
        # высаживаем урожай
        mc.setBlocks(x + 3, y + 2, z + 2, x + 4, y + 2, z + 8, crop_id)
        mc.setBlocks(x + 6, y + 2, z + 2, x + 7, y + 2, z + 8, crop_id)


def watermelon_farm():
    pos = get_build_origin(distance=3, width=11, length=11)
    greenhouse_build(pos, crop_id= 103)


def mushroom_farm():
    pos = get_build_origin(distance=3, width=11, length=11)
    greenhouse_build(pos, crop_id = 39)


def flower_farm():
    pos = get_build_origin(distance=3, width=11, length=11)
    greenhouse_build(pos, crop_id = 38)

def clear():
    mc.setBlocks(pos.x - 200, pos.y, pos.z - 200, pos.x + 200, pos.y + 50, pos.z + 200, 0)

def build_mega_farm():
    pos = get_build_origin(distance=4, width=28, length=26)

    #Левая теплица, вход справа, арбузы
    pos_left = Vec3(pos.x, pos.y, pos.z)
    greenhouse_build(pos_left, door_side="x_max", crop_id=103)

    # Правая теплица, вход справа, грибы
    pos_right = Vec3(pos.x + 17, pos.y, pos.z)
    greenhouse_build(pos_right, door_side="x_min", crop_id=39)

    # Третья теплица, перед нами, цветы
    pos_end = Vec3(pos.x + 8, pos.y, pos.z + 15)
    greenhouse_build(pos_end, door_side="z_min", crop_id=38)

    #Тропинка
    mc.setBlocks(pos.x + 11, pos.y - 1, pos.z, pos.x + 16, pos.y, pos.z + 14, 13)

    # Клумба посередине тропинки
    mc.setBlocks(pos.x + 13, pos.y - 1, pos.z, pos.x + 14, pos.y, pos.z + 14, 3)
    mc.setBlocks(pos.x + 13, pos.y, pos.z, pos.x + 14, pos.y, pos.z + 14, 38)

# ОСНОВНОЙ ЦИКЛ: Слушаем чат
mc.postToChat("=== COMMAND MENU ===")
mc.postToChat("Type 'watermelon' - Watermelon farm")
mc.postToChat("Type 'mushroom' - Mushroom farm")
mc.postToChat("Type 'flower' - Flower farm")
mc.postToChat("Type 'clear' - To clear space")
mc.postToChat("Type 'mega' - Mega farm")


while True:
    chat_events = mc.events.pollChatPosts()

    for event in chat_events:
        message = event.message.lower().strip()
        if message == "watermelon":
            watermelon_farm()
        elif message == "mushroom":
            mushroom_farm()
        elif message == "flower":
            flower_farm()
        elif message == "clear":
            clear()
        elif message == "mega":
            build_mega_farm()