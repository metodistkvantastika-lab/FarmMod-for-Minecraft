@echo off
python farm.py
pause